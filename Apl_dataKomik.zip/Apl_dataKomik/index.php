<!DOCTYPE html>
<html lang="en">
<head>
<title>Data Komik</title>
<link rel="stylesheet"  type="text/css" href="assets/css/bootstrap.min.css">
</head>
<body>
<script type="text/javascript" src="assets/js/jquery-3.7.0.js"></script>
<script type="text/javascript" src="assets/js/bootstrap.min.js"></script>
<?php
include('class/database.php');
include('class/komik.php');
?>

<h1>Aplikasi Data Komik</h1>
<hr/>
<p>
<a href="index.php">Home</a>
<a href="index.php?file=komik&aksi=tampil">Data Komik</a>
<a href="index.php?file=komik&aksi=tambah">Tambah Data </a>
</p>
<hr/>

<?php
if(isset($_GET['file'])){

include($_GET['file'].'.php');

} else {
echo '<h1 align="center">Selamat Datang</h1>';
}
?>
</body>
</html>