<?php
// membuat instance
$dataKomik=NEW Komik;
// aksi tampil data
if($_GET['aksi']=='tampil'){
// aksi untuk tampil data
$html = null;
$html .='<h3>Daftar List Komik</h3>';
$html .='<p>Berikut list yang terdaftar</p>';
$html .='<table border="1" width="100%">
<thead>
<th>No.</th>
<th>ID</th>
<th>Judul</th>
<th>Author</th>
<th>Studio</th>
<th>Chapter</th>
<th>Aksi</th>
</thead>
<tbody>';
// variabel $data menyimpan hasil return
$data = $dataKomik->tampil();
$no=null;
if(isset($data)){
foreach($data as $barisKomik){
$no++;
$html .='<tr>
<td>'.$no.'</td>
<td>'.$barisKomik->id_komik.'</td>
<td>'.$barisKomik->judul.'</td>
<td>'.$barisKomik->author.'</td>
<td>'.$barisKomik->studio.'</td>
<td>'.$barisKomik->chapter.'</td>
<td>
<a href="index.php?file=komik&aksi=edit&id='.$barisKomik->id_komik.'">Edit</a>
<a href="index.php?file=komik&aksi=hapus&id='.$barisKomik->id_komik.'">Hapus</a>
</td>
</tr>';
}
}
$html .='</tbody>
</table>';
echo $html;
}
// aksi tambah data
else if ($_GET['aksi']=='tambah') {
$html =null;
$html .='<h3>Form Tambah Data</h3>';
$html .='<p>Silahkan masukan data </p>';
$html .='<form method="POST" action="index.php?file=komik&aksi=simpan"
.input {
    border: none;
    outline: none;
    border-radius: 15px;
    padding: 1em;
    background-color: #ccc;
    box-shadow: inset 2px 5px 10px rgba(0,0,0,0.3);
    transition: 300ms ease-in-out;
  }
  
  .input:focus {
    background-color: white;
    transform: scale(1.05);
    box-shadow: 13px 13px 100px #969696,
               -13px -13px 100px #ffffff;
  }>';
$html .='<p>Id Komik<br/>';
$html .='<input type="text" name="txtId" placeholder="Masukan Id Komik" autofocus/></p>';
$html .='<p>Judul<br/>';
$html .='<input type="text" name="txtJudul" placeholder="Masukan Judul" size="30" required/></p>';
$html .='<p>Author<br/>';
$html .='<input type="text" name="txtAuthor" placeholder="Masukan Nama Author" size="30" required/>,';
$html .='<p>Studio<br/>';
$html .='<input type="text" name="txtStudio" placeholder="Masukan nama Studio" size="30" required></p>';
$html .='<p>Chapter<br/>';
$html .='<input type="text" name="txtChap" placeholder="Masukan jumlah Chapter" size="30" ></p>';
$html .='<p><input type="submit" name="tombolSimpan" value="Simpan"/></p>';
$html .='</form>';
echo $html;
}
// aksi tambah data
else if ($_GET['aksi']=='simpan') {
$data=array(
'id_komik'=>$_POST['txtId'],
'judul'=>$_POST['txtJudul'],
'author'=>$_POST['txtAuthor'],
'studio'=>$_POST['txtStudio'],
'chapter'=>$_POST['txtChap']
);
// simpan siswa dengan menjalankan method simpan
$dataKomik->simpan($data);
echo '<meta http-equiv="refresh" content="0; url=index.php?file=komik&aksi=tampil">';
}
// aksi tambah data
else if ($_GET['aksi']=='edit') {
// ambil data siswa
$komik=$dataKomik->detail($_GET['id']);
$html =null;
$html .='<h3>Form Tambah</h3>';
$html .='<p>Silahkan masukan data </p>';
$html .='<form method="POST" action="index.php?file=komik&aksi=update">';
$html .='<p>Id Komik<br/>';
$html .='<input type="text" name="txtId" value="'.$komik->id_komik.'" placeholder="Masukan Id Komik" readonly/></p>';
$html .='<p>Judul<br/>';
$html .='<input type="text" name="txtJudul" value="'.$komik->judul.'" placeholder="Masukan Judul" size="30" required autofocus/></p>';
$html .='<p>Author<br/>';
$html .='<input type="text" name="txtAuthor" value="'.$komik->author.'" placeholder="Masukan nama Author" size="30" required/>,';
$html .='<p>Studio<br/>';
$html .='<input type="text" name="txtStudio" value="'.$komik->studio.'" placeholder="Masukan nama Author" size="30" required/>,';
$html .='<p>Chapter<br/>';
$html .='<input type="text" name="txtChap" value="'.$komik->chapter.'" placeholder="Masukan jumlah Chapter" size="30" ></p>';
$html .='<p><input type="submit" name="tombolSimpan" value="Simpan"/></p>';
$html .='</form>';
echo $html;
}
// aksi tambah data
else if ($_GET['aksi']=='update') {
$data=array(
'judul'=>$_POST['txtJudul'],
'author'=>$_POST['txtAuthor'],
'studio'=>$_POST['txtStudio'],
'chapter'=>$_POST['txtChap']
);
$dataKomik->update($_POST['txtId'],$data);
echo '<meta http-equiv="refresh" content="0; url=index.php?file=komik&aksi=tampil">';
}
// aksi tambah data
else if ($_GET['aksi']=='hapus') {
$dataKomik->hapus($_GET['id']);
echo '<meta http-equiv="refresh" content="0; url=index.php?file=komik&aksi=tampil">';
}
// aksi tidak terdaftar
else {
echo '<p>Error 404 : Halaman tidak ditemukan !</p>';
}
?>